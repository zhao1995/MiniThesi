
      integer            maxfct,mnum,nrhs,mtype,npzs, istats
      common /xpardiso4/ maxfct,mnum,nrhs,mtype,npzs, istats

      integer            iparm(64)
      common /xpardiso4/ iparm

      integer*8          pt(64)
      common /xpardiso8/ pt

